$(document).ready(function() {
    // Search functionality
    $('#search-bar').on('input', function() {
        let query = $(this).val().toUpperCase();// retrive search data and converts it to lowercase for case-insensitive searching,
        
        if (query.length > 2) {//show the result after typing 2 words 
            $.getJSON('books.json', function(data) {  //Initiates an AJAX request to fetch the book data from json file
                let results = data.books.filter(book => book.title.toUpperCase().includes(query.toUpperCase()) || book.author.toUpperCase().includes(query.toUpperCase())//filtering the search
                );
                
                let resultsHtml = results.length //accessing html to display resilt
                    ? `<ul>${results.map(book => `<li>${book.title} by ${book.author}</li>`).join('')}</ul>`
                    : '<p>No results found.</p>';
                
                $('#search-results').html(resultsHtml).show();//if nno result found the this message will be displayed 
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.error("Search Error:", textStatus, errorThrown);//Handles any errors that occur during the AJAX request
                $('#search-results').html('<p>Failed to load book data. Please try again later.</p>').show();
            });
        } else {
            $('#search-results').hide();//If the query length is 2 characters or less, hides the #search-results element to avoid showing partial or unnecessary results.
        }
    });

    // Hide search results when clicking outside
    $(document).on('click', function(event) {
        if (!$(event.target).closest('#search-bar, #search-results').length) {
            $('#search-results').hide();
        }
    });  
});
  // Load more books functionality
  $('#load-more-books').on('click', function() {//adding event listner on click action 
    console.log('Load More Books button clicked'); 
    
    $.getJSON('books.json', function(data) {//Initiates an AJAX request to fetch the book data from json file
        if (data.books && data.books.length) {//data.books: Refers to the array of books from the JSON data.and length will make sure that the book array is not empty 
            let booksHtml = data.books.map(book => 
                `<tr><td>${book.title}</td><td>${book.author}</td><td>${book.price}</td></tr>`
            ).join('');//Joins all the rows into a single string.
            
            $('#book-table tbody').append(booksHtml);
        } else {
            $('#book-table tbody').append('<tr><td colspan="3">No more books to load.</td></tr>');
        }
        // Handles errors if the AJAX request fails
    }).fail(function(jqXHR, textStatus, errorThrown) {// if methods got failed 
        console.error("Load More Error:", textStatus, errorThrown);
        $('#book-table tbody').append('<tr><td colspan="3">Failed to load more books. Please try again later.</td></tr>');
    });
});
