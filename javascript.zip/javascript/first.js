firstname="rakash";
console.log(firstname);
let age="24";

console.log(age);
age=100;
console.log(age);
{var a=10;
console.log("block"+a);}
console.log("global"+a);

let fullName="rakash rasheed";
let totalPrice=24;
console.log(fullName);
isFollow= true;
 let check= null;




