firstname=rakash;
console.log(firstname);




