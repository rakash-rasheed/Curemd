$(document).ready(function() {
    // Search functionality
    $('#search-bar').on('input', function() {
        var query = $(this).val();

        if (query.length > 2) {
            $.ajax({
                url: 'books.json', // Ensure this path is correct
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    var results = data.books.filter(function(book) {
                        return book.title.toLowerCase().includes(query.toLowerCase()) || 
                               book.author.toLowerCase().includes(query.toLowerCase());
                    });
                    var resultsHtml = '<ul>';

                    results.forEach(function(book) {
                        resultsHtml += '<li>' + book.title + ' by ' + book.author + '</li>';
                    });

                    resultsHtml += '</ul>';
                    $('#search-results').html(resultsHtml).show();
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log("Search Error: ", textStatus, errorThrown);
                    console.log("Search Response Text: ", jqXHR.responseText);
                    $('#search-results').html('<p>Failed to load book data. Please try again later.</p>').show();
                }
            });
        } else {
            $('#search-results').hide();
        }
    });

    // Hide search results when clicking outside
    $(document).on('click', function(event) {
        if (!$(event.target).closest('#search-bar, #search-results').length) {
            $('#search-results').hide();
        }
    });

    // Load more books functionality
    $('#load-more-books').on('click', function() {
        console.log('Load More Books button clicked'); // Debugging line
        $.ajax({
            url: 'more-books.json', // Ensure this path is correct
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data.books && data.books.length > 0) {
                    var booksHtml = '';

                    data.books.forEach(function(book) {
                        booksHtml += '<tr><td>' + book.title + '</td><td>' + book.author + '</td><td>' + book.price + '</td></tr>';
                    });

                    $('#book-table tbody').append(booksHtml);
                } else {
                    $('#book-table tbody').append('<tr><td colspan="3">No more books to load.</td></tr>');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log("Load More Error: ", textStatus, errorThrown);
                console.log("Load More Response Text: ", jqXHR.responseText);
                $('#book-table tbody').append('<tr><td colspan="3">Failed to load more books. Please try again later.</td></tr>');
            }
        });
    });
});
