﻿using Book_Shop.Models;
using System.Collections.Generic;
using System.Linq;

namespace Book_Shop.DataAccessLayer
{
    public class BookDAL
    {
        private static List<Book> Books = new List<Book>
        {
            new Book { Id = 1, Author = "Author1", Description = "A high-performance laptop", Price = 999.99m },
            new Book { Id = 2, Author = "Author2", Description = "A latest model smartphone", Price = 699.99m },
            new Book { Id = 3, Author = "Author3", Description = "A high-performance watch", Price = 599.99m },
        };

        public List<Book> GetBooks()
        {
            return Books;
        }

        public Book GetBook(int id)
        {
            return Books.FirstOrDefault(p => p.Id == id);
        }

        public List<Book> GetBooksByAuthor(string author)
        {
            return Books.Where(p => p.Author.Equals(author, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public void AddBook(Book book)
        {
            book.Id = Books.Max(p => p.Id) + 1;
            Books.Add(book);
        }

        public void UpdateBook(Book book)
        {
            var existingBook = Books.FirstOrDefault(p => p.Id == book.Id);

            if (existingBook != null)
            {
                existingBook.Author = book.Author;
                existingBook.Description = book.Description;
                existingBook.Price = book.Price;
            }
        }

        public void DeleteBook(int id)
        {
            var book = Books.FirstOrDefault(p => p.Id == id);
            if (book != null)
            {
                Books.Remove(book);
            }
        }
    }
}
