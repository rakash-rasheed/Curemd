﻿using Microsoft.AspNetCore.Mvc;
using Book_Shop.Models;
using Book_Shop.BusinessLayer;
using System.Collections.Generic;
using System.Linq;

namespace Book_Shop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly BookBL _bookBL = new BookBL();

        // GET: api/Books
        [HttpGet]
        public ActionResult<IEnumerable<Book>> GetBooks()
        {
            var books = _bookBL.GetBooks();
            return Ok(books);
        }

        // GET: api/Books/3
        [HttpGet("{id}")]
        public ActionResult<Book> GetBook(int id)
        {
            var book = _bookBL.GetBook(id);

            if (book == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            return Ok(book);
        }

        // GET: api/Books/author/AuthorName
        [HttpGet("author/{author}")]
        public ActionResult<IEnumerable<Book>> GetBooksByAuthor(string author)
        {
            var books = _bookBL.GetBooksByAuthor(author);

            if (books == null || !books.Any())
            {
                return NotFound(new { Message = "Books by the specified author not found" });
            }

            return Ok(books);
        }

        // POST: api/Books
        [HttpPost]
        public ActionResult<Book> PostBook(Book book)
        {
            _bookBL.AddBook(book);
            return CreatedAtAction(nameof(GetBook), new { id = book.Id }, book);
        }

        // PUT: api/Books/2
        [HttpPut("{id}")]
        public IActionResult PutBook(int id, Book book)
        {
            var existingBook = _bookBL.GetBook(id);
            if (existingBook == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            _bookBL.UpdateBook(id, book);
            return Ok(new { Message = "Book updated successfully" });
        }

        // DELETE: api/Books/1
        [HttpDelete("{id}")]
        public IActionResult DeleteBook(int id)
        {
            var existingBook = _bookBL.GetBook(id);
            if (existingBook == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            _bookBL.DeleteBook(id);
            return Ok(new { Message = "Book deleted successfully" });
        }
    }
}
