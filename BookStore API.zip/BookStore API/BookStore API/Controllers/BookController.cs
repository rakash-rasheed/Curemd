﻿using Microsoft.AspNetCore.Mvc;
using MyBookstoreApi.Models;
using System.Collections.Generic;
using System.Linq;

namespace MyBookstoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private static readonly List<Book> Books = new List<Book>
        {
            new Book { Id = 1, Title = "Atomic habits", Author = "F. Scott Fitzgerald", Description = "A novel set in the Roaring Twenties.", ImageUrl = "http://example.com/image.jpg" },
            new Book { Id = 2, Title = "1984", Author = "George Orwell", Description = "A dystopian social science fiction novel.", ImageUrl = "http://example.com/image2.jpg" }
        };

        // GET: api/Books
        [HttpGet]
        public ActionResult<IEnumerable<Book>> GetBooks()
        {
            return Books;
        }

        // GET: api/Books/1
        [HttpGet("{id}")]
        public ActionResult<Book> GetBook(int id)
        {
            var book = Books.FirstOrDefault(b => b.Id == id);
            if (book == null)
            {
                return NotFound();
            }
            return book;
        }

        // POST  data
        [HttpPost]
        public ActionResult<Book> PostBook(Book book)
        {
            book.Id = Books.Max(b => b.Id) + 1;
            Books.Add(book);
            return CreatedAtAction(nameof(GetBook), new { id = book.Id }, book);
        }

        // PUT data 
        [HttpPut("{id}")]
        public IActionResult PutBook(int id, Book book)
        {
            var existingBook = Books.FirstOrDefault(b => b.Id == id);
            if (existingBook == null)
            {
                return NotFound();
            }
            existingBook.Title = book.Title;
            existingBook.Author = book.Author;
            existingBook.Description = book.Description;
            existingBook.ImageUrl = book.ImageUrl;
            return NoContent();
        }

        // DELETE book
        [HttpDelete("{id}")]
        public IActionResult DeleteBook(int id)
        {
            var book = Books.FirstOrDefault(b => b.Id == id);
            if (book == null)
            {
                return NotFound();
            }
            Books.Remove(book);
            return NoContent();
        }
    }
}
